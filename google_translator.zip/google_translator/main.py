import tkinter as tk
from googletrans import Translator

def translate_text():
    text = entry.get()
    translator = Translator()
    translated_text = translator.translate(text, src=source_language.get(), dest=target_language.get())
    result_label.config(text=translated_text.text)

# Create a main window
root = tk.Tk()
root.title("Google Translator")

# Create and place widgets
label1 = tk.Label(root, text="Enter text to translate:",background="yellow",font=('arial',12))
label1.pack(pady=10)

entry = tk.Entry(root, width=40)
entry.pack()

source_label = tk.Label(root, text="Source Language:",font=('arial',15))
source_label.pack(pady=8)

source_language = tk.StringVar()
source_language.set("en",)  # Default source language is English

source_dropdown = tk.OptionMenu(root, source_language, "en", "fr", "de","ta")
source_dropdown.pack()

target_label = tk.Label(root, text="Target Language:",font=('arial',15))
target_label.pack(pady=8)

target_language = tk.StringVar()
target_language.set("es")  # Default target language is Spanish

target_dropdown = tk.OptionMenu(root, target_language, "en", "fr", "de","ta")
target_dropdown.pack()

translate_button = tk.Button(root, text="Translate", command=translate_text)
translate_button.pack(pady=10)

result_label = tk.Label(root, text="", wraplength=300,font=('arial',15),background="light blue")
result_label.pack()

root.mainloop()
